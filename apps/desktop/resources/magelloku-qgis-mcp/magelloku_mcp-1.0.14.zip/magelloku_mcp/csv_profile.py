"""Streaming CSV facts; no CRS or semantic interpretation is inferred."""
import csv
import math
import os
import time


def profile_csv(path, delimiter=None, encoding="utf-8-sig"):
    started = time.monotonic()
    before = os.stat(path)
    with open(path, "r", encoding=encoding, newline="") as stream:
        sample = stream.read(32768)
        stream.seek(0)
        if delimiter is None:
            try:
                delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
            except csv.Error as exc:
                raise ValueError("CSV delimiter is ambiguous; specify delimiter explicitly") from exc
        if len(delimiter) != 1:
            raise ValueError("delimiter must be one character")
        reader = csv.reader(stream, delimiter=delimiter)
        headers = next(reader, None)
        if not headers or len(set(headers)) != len(headers) or any(not name.strip() for name in headers):
            raise ValueError("CSV requires unique, non-empty column headers")
        fields = {name: {"missing": 0, "numeric_count": 0, "non_numeric_count": 0, "non_finite_count": 0,
                         "min": None, "max": None, "value_counts": {}, "value_counts_complete": True} for name in headers}
        rows, preview = 0, []
        for line, values in enumerate(reader, 2):
            if time.monotonic() - started > 15:
                raise ValueError("CSV inspection exceeded 15 seconds; no complete statistics reported. Partition or inspect the file explicitly.")
            if not values:
                continue
            if len(values) != len(headers):
                raise ValueError(f"CSV row {line} has {len(values)} values; expected {len(headers)}")
            rows += 1
            if len(preview) < 5:
                preview.append(dict(zip(headers, values)))
            for name, value in zip(headers, values):
                field = fields[name]
                stripped = value.strip()
                counts = field["value_counts"]
                if field["value_counts_complete"]:
                    if stripped not in counts and len(counts) >= 50:
                        field["value_counts_complete"] = False
                        field["value_counts"] = {}  # do not imply partial counts are a distribution
                    else:
                        counts[stripped] = counts.get(stripped, 0) + 1
                if not stripped:
                    field["missing"] += 1
                    continue
                try:
                    number = float(stripped)
                except ValueError:
                    field["non_numeric_count"] += 1
                    continue
                if not math.isfinite(number):
                    field["non_finite_count"] += 1
                    continue
                field["numeric_count"] += 1
                field["min"] = number if field["min"] is None else min(number, field["min"])
                field["max"] = number if field["max"] is None else max(number, field["max"])
    after = os.stat(path)
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("CSV changed during inspection; repeat before using these statistics")
    return {"path": os.path.abspath(path), "size_bytes": after.st_size, "mtime_ns": after.st_mtime_ns,
            "delimiter": delimiter, "encoding": encoding, "row_count": rows, "columns": headers,
            "fields": fields, "preview": preview, "complete": True,
            "note": "Facts from the selected file only. Numeric parsing uses decimal dot; CRS, units and column roles require explicit confirmation."}
