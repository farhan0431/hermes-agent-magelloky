"""Handlers for print layouts, layout items and atlas export."""

import math
import os
from typing import ClassVar

from qgis.core import (
    QgsCoordinateTransform,
    QgsLayoutExporter,
    QgsLayoutItemMap,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsPrintLayout,
    QgsProject,
    QgsRectangle,
)
from qgis.PyQt.QtGui import QColor

from ..compat import IODEVICE_WRITEONLY, LAYOUT_SUCCESS, RENDER_UNIT_POINTS
from ..errors import CommandError
from ..registry import command


class LayoutHandlers:
    """Print layouts, layout items and atlas export."""

    @command
    def get_layout_screenshot(self, layout_name, page=0, dpi=150, **kwargs):
        import base64
        from qgis.PyQt.QtCore import QBuffer, QByteArray, QSize
        layout = self._get_layout(layout_name)
        if int(page) < 0 or int(page) >= layout.pageCollection().pageCount():
            raise CommandError("Layout page is out of range")
        image = QgsLayoutExporter(layout).renderPageToImage(int(page), QSize(), max(72, min(float(dpi), 180)))
        if image.isNull():
            raise CommandError("Layout rendering returned an empty image")
        data = QByteArray()
        buffer = QBuffer(data)
        buffer.open(IODEVICE_WRITEONLY)
        if not image.save(buffer, "PNG"):
            raise CommandError("Failed to encode layout preview")
        buffer.close()
        return {"layout_name": layout_name, "page": int(page), "base64_data": base64.b64encode(bytes(data)).decode("ascii"), "mime_type": "image/png", "width": image.width(), "height": image.height()}

    @command
    def list_layouts(self, **kwargs):
        manager = QgsProject.instance().layoutManager()
        layouts = []
        for layout in manager.layouts():
            layouts.append(
                {
                    "name": layout.name(),
                    "page_count": layout.pageCollection().pageCount(),
                }
            )
        return {"layouts": layouts, "count": len(layouts)}

    # format -> (QgsLayoutExporter settings class, exporter method). Named
    # rather than referenced so the attribute lookup happens on the running
    # QGIS, as elsewhere in the plugin; the accepted list is the table's keys.
    _LAYOUT_EXPORTS: ClassVar[dict] = dict(
        {"pdf": ("PdfExportSettings", "exportToPdf"), "svg": ("SvgExportSettings", "exportToSvg")},
        **dict.fromkeys(
            ("png", "jpg", "jpeg", "tif", "tiff", "bmp"),
            ("ImageExportSettings", "exportToImage"),
        ),
    )

    @command
    def export_layout(self, layout_name, path, format="pdf", dpi=300, **kwargs):
        layout = self._get_layout(layout_name)
        exporter = QgsLayoutExporter(layout)
        settings_name, method = self._pick(self._LAYOUT_EXPORTS, format.lower(), "format")
        settings = getattr(QgsLayoutExporter, settings_name)()
        settings.dpi = dpi
        result = getattr(exporter, method)(path, settings)

        if result != LAYOUT_SUCCESS:
            reason = exporter.errorMessage()
            detail = f": {reason}" if reason else ""
            raise CommandError(f"Export failed with code: {result}{detail}")

        preview = self.get_layout_screenshot(layout_name, dpi=120)
        return {"ok": True, "path": path, **preview}

    @command
    def create_layout(self, name, **kwargs):
        """Create a new print layout."""
        project = QgsProject.instance()
        layout = QgsPrintLayout(project)
        layout.initializeDefaults()
        layout.setName(name)
        # addLayout refuses a duplicate name; ignoring that sent every later
        # item call to the existing layout of that name.
        if not project.layoutManager().addLayout(layout):
            raise CommandError(f"Could not add layout '{name}' (a layout with that name exists?)")
        return {"ok": True, "name": name}

    @command
    def add_layout_map(self, layout_name, x, y, width, height, **kwargs):
        """Add a map item to a print layout."""
        layout = self._get_layout(layout_name)
        x, y, width, height = self._validate_page_bounds(layout, x, y, width, height)
        map_item = QgsLayoutItemMap(layout)
        map_item.attemptMove(QgsLayoutPoint(x, y))
        map_item.attemptResize(QgsLayoutSize(width, height))
        extent = self.iface.mapCanvas().extent()
        if extent.isEmpty():
            raise CommandError("The QGIS map canvas has an empty extent")
        map_item.zoomToExtent(extent)
        layout.addLayoutItem(map_item)
        return {"ok": True}

    def _get_layout(self, layout_name):
        """Get a print layout by name or raise."""
        layout = QgsProject.instance().layoutManager().layoutByName(layout_name)
        if not layout:
            raise CommandError(f"Layout not found: {layout_name}")
        return layout

    def _validate_page_bounds(self, layout, x, y, width, height):
        """Reject invalid geometry before an item is added to the live layout."""
        try:
            x, y, width, height = map(float, (x, y, width, height))
        except (TypeError, ValueError):
            raise CommandError("Layout item coordinates and size must be numeric")
        if not all(math.isfinite(value) for value in (x, y, width, height)):
            raise CommandError("Layout item coordinates and size must be finite numbers")
        if width <= 0 or height <= 0:
            raise CommandError("Layout item width and height must be greater than zero")
        if layout.pageCollection().pageCount() < 1:
            raise CommandError("Layout has no page to place items on")

        page_size = layout.pageCollection().page(0).sizeWithUnits()
        page_width, page_height = page_size.width(), page_size.height()
        tolerance = 0.01
        if (
            x < 0
            or y < 0
            or x + width > page_width + tolerance
            or y + height > page_height + tolerance
        ):
            raise CommandError(
                f"Layout item ({x:g}, {y:g}, {width:g}, {height:g} mm) exceeds "
                f"page bounds ({page_width:g} x {page_height:g} mm)"
            )
        return x, y, width, height

    def _find_layout_map(self, layout, map_item_id=None):
        """The map item with id/uuid *map_item_id*, else the first map item.

        An explicit id that matches nothing raises: falling back to the first
        map linked the legend or scale bar to a map the caller did not name.
        """
        maps = [it for it in layout.items() if isinstance(it, QgsLayoutItemMap)]
        if map_item_id:
            for m in maps:
                if m.id() == map_item_id or m.uuid() == map_item_id:
                    return m
            raise CommandError(f"Map item not found in layout: {map_item_id}")
        return maps[0] if maps else None

    @command
    def get_layout_info(self, layout_name, **kwargs):
        """List items in a print layout (type, id, position, size)."""
        layout = self._get_layout(layout_name)
        items = []
        for item in layout.items():
            if not hasattr(item, "uuid"):
                continue
            try:
                pos = item.positionWithUnits()
                size = item.sizeWithUnits()
                x, y = pos.x(), pos.y()
                w, h = size.width(), size.height()
            except Exception:
                x = y = w = h = None
            items.append(
                {
                    "id": item.id(),
                    "uuid": item.uuid(),
                    "type": type(item).__name__,
                    "x": x,
                    "y": y,
                    "width": w,
                    "height": h,
                }
            )
        return {
            "layout": layout_name,
            "items": items,
            "count": len(items),
            "page_count": layout.pageCollection().pageCount(),
            "pages": [
                {
                    "page": page_index,
                    "width": layout.pageCollection().page(page_index).sizeWithUnits().width(),
                    "height": layout.pageCollection().page(page_index).sizeWithUnits().height(),
                    "units": "mm",
                }
                for page_index in range(layout.pageCollection().pageCount())
            ],
        }

    @command
    def fit_layout_map_to_layer(
        self,
        layout_name,
        layer,
        map_item_id=None,
        margin=0.08,
        scale=None,
        **kwargs,
    ):
        """Fit a layout map item to a layer extent without changing item geometry."""
        project = QgsProject.instance()
        layout = self._get_layout(layout_name)
        map_item = self._find_layout_map(layout, map_item_id)
        if map_item is None:
            raise CommandError(f"Layout has no map item: {layout_name}")

        layer_key = str(layer or "").strip()
        target_layer = project.mapLayer(layer_key)
        if target_layer is None:
            matches = project.mapLayersByName(layer_key)
            if len(matches) > 1:
                raise CommandError(f"More than one layer is named {layer_key!r}; use its layer ID")
            target_layer = matches[0] if matches else None
        if target_layer is None:
            raise CommandError(f"Layer not found: {layer_key}")

        try:
            margin = float(margin)
        except (TypeError, ValueError):
            raise CommandError("margin must be a number between 0 and 1")
        if not math.isfinite(margin) or margin < 0 or margin > 1:
            raise CommandError("margin must be a finite number between 0 and 1")
        if scale is not None:
            try:
                scale = float(scale)
            except (TypeError, ValueError):
                raise CommandError("scale must be a positive denominator")
            if not math.isfinite(scale) or scale <= 0:
                raise CommandError("scale must be a finite positive denominator")

        source_extent = target_layer.extent()
        if source_extent.isEmpty():
            raise CommandError(f"Layer has an empty extent: {target_layer.name()}")
        target_extent = QgsRectangle(source_extent)
        if target_layer.crs() != map_item.crs():
            transform = QgsCoordinateTransform(target_layer.crs(), map_item.crs(), project)
            target_extent = transform.transformBoundingBox(target_extent)
        if target_extent.isEmpty():
            raise CommandError("Layer extent could not be transformed to the layout map CRS")

        min_margin = 0.000001 if map_item.crs().isGeographic() else 1.0
        pad_x = max(target_extent.width() * margin, min_margin)
        pad_y = max(target_extent.height() * margin, min_margin)
        target_extent = QgsRectangle(
            target_extent.xMinimum() - pad_x,
            target_extent.yMinimum() - pad_y,
            target_extent.xMaximum() + pad_x,
            target_extent.yMaximum() + pad_y,
        )

        old_extent = QgsRectangle(map_item.extent())
        old_scale = map_item.scale()
        try:
            map_item.zoomToExtent(target_extent)
            if scale is not None:
                map_item.setScale(scale)
            map_item.refresh()
        except Exception as exc:
            try:
                map_item.zoomToExtent(old_extent)
                map_item.setScale(old_scale)
                map_item.refresh()
            except Exception:
                pass
            raise CommandError(f"Could not fit layout map to layer: {exc}")

        return {
            "ok": True,
            "layout": layout_name,
            "map_item_id": map_item.id(),
            "layer_id": target_layer.id(),
            "layer_name": target_layer.name(),
            "crs": map_item.crs().authid(),
            "scale": map_item.scale(),
            "extent": {
                "xmin": map_item.extent().xMinimum(),
                "ymin": map_item.extent().yMinimum(),
                "xmax": map_item.extent().xMaximum(),
                "ymax": map_item.extent().yMaximum(),
            },
            "margin": margin,
            "geometry_unchanged": True,
        }

    @staticmethod
    def _style_label(label, color, font_size):
        """Set a layout label's colour and size through the current API.

        QGIS 4 deprecates setFontColor()/font()/setFont() on QgsLayoutItemLabel
        in favour of a QgsTextFormat, and each call logs a DeprecationWarning
        with a traceback into the user's QGIS log. setTextFormat() arrived in
        3.24, below the plugin's 3.28 minimum, but the old path is kept as a
        fallback rather than assuming: a missing method here would take out
        every layout label.
        """
        text_format = getattr(label, "textFormat", None)
        if text_format is not None and hasattr(label, "setTextFormat"):
            fmt = text_format()
            fmt.setColor(QColor(color))
            fmt.setSize(float(font_size))
            fmt.setSizeUnit(RENDER_UNIT_POINTS)
            label.setTextFormat(fmt)
            return
        label.setFontColor(QColor(color))
        font = label.font()
        font.setPointSize(int(font_size))
        label.setFont(font)

    @command
    def add_layout_label(
        self,
        layout_name,
        text,
        x=10,
        y=10,
        width=100,
        height=20,
        font_size=12,
        color="#000000",
        **kwargs,
    ):
        """Add a text label to a print layout. Supports [% expression %] in text."""
        from qgis.core import QgsLayoutItemLabel

        layout = self._get_layout(layout_name)
        x, y, width, height = self._validate_page_bounds(layout, x, y, width, height)
        label = QgsLayoutItemLabel(layout)
        label.setText(text)
        self._style_label(label, color, font_size)
        label.attemptMove(QgsLayoutPoint(x, y))
        label.attemptResize(QgsLayoutSize(width, height))
        layout.addLayoutItem(label)
        return {"ok": True, "uuid": label.uuid()}

    @command
    def add_layout_legend(
        self,
        layout_name,
        map_item_id=None,
        x=10,
        y=10,
        width=80,
        height=100,
        title="Legend",
        **kwargs,
    ):
        """Add a legend to a print layout, linked to a map item."""
        from qgis.core import QgsLayoutItemLegend

        layout = self._get_layout(layout_name)
        x, y, width, height = self._validate_page_bounds(layout, x, y, width, height)
        legend = QgsLayoutItemLegend(layout)
        legend.setTitle(title)
        map_item = self._find_layout_map(layout, map_item_id)
        if map_item:
            legend.setLinkedMap(map_item)
        legend.attemptMove(QgsLayoutPoint(x, y))
        legend.attemptResize(QgsLayoutSize(width, height))
        layout.addLayoutItem(legend)
        return {"ok": True, "uuid": legend.uuid()}

    @command
    def add_layout_scalebar(
        self,
        layout_name,
        map_item_id=None,
        x=10,
        y=180,
        width=80,
        height=20,
        style="Single Box",
        **kwargs,
    ):
        """Add a scale bar to a print layout, linked to a map item."""
        from qgis.core import QgsLayoutItemScaleBar

        layout = self._get_layout(layout_name)
        bar = QgsLayoutItemScaleBar(layout)
        bar.setStyle(style)
        map_item = self._find_layout_map(layout, map_item_id)
        if map_item:
            bar.setLinkedMap(map_item)
        bar.applyDefaultSize()
        size = bar.sizeWithUnits()
        x, y, _, _ = self._validate_page_bounds(
            layout, x, y, size.width(), size.height()
        )
        bar.attemptMove(QgsLayoutPoint(x, y))
        layout.addLayoutItem(bar)
        return {"ok": True, "uuid": bar.uuid()}

    @command
    def add_layout_picture(self, layout_name, path, x=10, y=10, width=30, height=30, **kwargs):
        """Add a picture/SVG (logo, north arrow) to a print layout."""
        from qgis.core import QgsLayoutItemPicture

        layout = self._get_layout(layout_name)
        x, y, width, height = self._validate_page_bounds(layout, x, y, width, height)
        pic = QgsLayoutItemPicture(layout)
        pic.setPicturePath(path)
        pic.attemptMove(QgsLayoutPoint(x, y))
        pic.attemptResize(QgsLayoutSize(width, height))
        layout.addLayoutItem(pic)
        return {"ok": True, "uuid": pic.uuid()}

    @command
    def add_layout_table(
        self,
        layout_name,
        layer_id,
        x=10,
        y=10,
        width=180,
        height=80,
        max_rows=20,
        **kwargs,
    ):
        """Add an attribute table for a vector layer to a print layout."""
        from qgis.core import QgsLayoutFrame, QgsLayoutItemAttributeTable

        layer = self._get_vector_layer(layer_id)
        layout = self._get_layout(layout_name)
        x, y, width, height = self._validate_page_bounds(layout, x, y, width, height)
        table = QgsLayoutItemAttributeTable.create(layout)
        table.setVectorLayer(layer)
        table.setMaximumNumberOfFeatures(int(max_rows))
        layout.addMultiFrame(table)
        frame = QgsLayoutFrame(layout, table)
        frame.attemptMove(QgsLayoutPoint(x, y))
        frame.attemptResize(QgsLayoutSize(width, height))
        table.addFrame(frame)
        return {"ok": True, "uuid": frame.uuid()}

    @command
    def configure_atlas(
        self,
        layout_name,
        coverage_layer,
        enabled=True,
        page_name_expression=None,
        filter_expression=None,
        sort_expression=None,
        **kwargs,
    ):
        """Configure the atlas of a print layout (coverage layer, filter, sort)."""
        layer = self._get_vector_layer(coverage_layer)
        layout = self._get_layout(layout_name)
        atlas = layout.atlas()
        atlas.setEnabled(bool(enabled))
        atlas.setCoverageLayer(layer)
        if page_name_expression:
            atlas.setPageNameExpression(page_name_expression)
        if filter_expression:
            atlas.setFilterFeatures(True)
            # Returns (ok, error); a syntax error otherwise left count 0 and ok.
            ok, error = atlas.setFilterExpression(filter_expression)
            if not ok:
                raise CommandError(f"Atlas filter expression error: {error}")
        if sort_expression:
            atlas.setSortFeatures(True)
            atlas.setSortExpression(sort_expression)
        atlas.updateFeatures()
        return {
            "ok": True,
            "coverage_layer": layer.name(),
            "enabled": bool(enabled),
            "count": atlas.count(),
        }

    @command
    def export_atlas(self, layout_name, output_path, format="pdf", dpi=300, **kwargs):
        """Export an atlas: single multi-page PDF, or one image file per feature."""

        layout = self._get_layout(layout_name)
        atlas = layout.atlas()
        if not atlas.enabled():
            raise CommandError("Atlas not enabled; call configure_atlas first")
        atlas.updateFeatures()
        fmt = format.lower()
        if fmt == "pdf":
            settings = QgsLayoutExporter.PdfExportSettings()
            settings.dpi = dpi
            result, error = QgsLayoutExporter.exportToPdf(atlas, output_path, settings)
        elif fmt in ("png", "jpg", "jpeg", "tif", "tiff"):
            os.makedirs(output_path, exist_ok=True)
            settings = QgsLayoutExporter.ImageExportSettings()
            settings.dpi = dpi
            base = os.path.join(output_path, layout_name)
            result, error = QgsLayoutExporter.exportToImage(atlas, base, fmt, settings)
        else:
            raise CommandError(f"Unsupported atlas format: {format}")
        if result != LAYOUT_SUCCESS:
            raise CommandError(f"Atlas export failed: {error}")
        return {"ok": True, "output": output_path, "count": atlas.count()}

    @command
    def remove_layout(self, layout_name, **kwargs):
        """Remove a print layout from the project."""
        layout = self._get_layout(layout_name)
        QgsProject.instance().layoutManager().removeLayout(layout)
        return {"ok": True, "removed": layout_name}
